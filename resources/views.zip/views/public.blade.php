<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Absensi Real-Time</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet" />
  <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
  <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css" rel="stylesheet" />
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&display=swap" rel="stylesheet" />

  <style>
    :root {
      --bg-dark: #0f2027;
      --bg-light: #f2f2f2;
      --text-dark: #ffffff;
      --text-light: #333333;
      --primary-color: #00d4ff;
    }

    body {
      font-family: 'Poppins', sans-serif;
      background-color: var(--bg-dark);
      color: var(--text-dark);
      min-height: 100vh;
      margin: 0;
      display: flex;
      align-items: center;
      justify-content: center;
      transition: background 0.4s, color 0.4s;
    }

    body.light-mode {
      background-color: var(--bg-light);
      color: var(--text-light);
    }

    .container {
      max-width: 400px;
      padding: 20px;
      position: relative;
    }

    .brand-logo {
      display: flex;
      align-items: center;
      justify-content: center;
      gap: 12px;
      margin-bottom: 20px;
    }

    .brand-logo img {
      height: 45px;
    }

    .brand-logo h1 {
      font-size: 1.6rem;
      font-weight: 600;
      margin: 0;
    }

    .btn-login {
      background: var(--primary-color);
      color: #0f2027;
      font-weight: 600;
      border: none;
      transition: 0.3s;
      border-radius: 10px;
    }

    .btn-login:hover {
      background: #ffffff;
      color: #203a43;
    }

    .attendance-box {
      backdrop-filter: blur(10px);
      background: rgba(255, 255, 255, 0.1);
      border-radius: 15px;
      padding: 25px 20px;
      box-shadow: 0 8px 25px rgba(0, 0, 0, 0.3);
      margin-top: 30px;
      animation: fadeIn 0.7s ease;
      color: inherit;
    }

    body.light-mode .attendance-box {
      background: rgba(255, 255, 255, 0.8);
      color: var(--text-light);
    }

    .attendance-box h2 {
      font-size: 1.4rem;
      font-weight: 600;
      margin-bottom: 10px;
    }

    .attendance-box p {
      font-size: 0.95rem;
      margin: 5px 0;
    }

    .attendance-box p i {
      margin-right: 6px;
      color: var(--primary-color);
    }

    @keyframes fadeIn {
      from { opacity: 0; transform: translateY(15px); }
      to { opacity: 1; transform: translateY(0); }
    }

    .mode-toggle {
      position: absolute;
      top: 15px;
      right: 15px;
      font-size: 1.2rem;
      cursor: pointer;
      color: var(--primary-color);
    }

    .loading-spinner {
      display: none;
      margin-top: 20px;
      text-align: center;
    }

    .spinner-border {
      color: var(--primary-color);
    }

    .show {
      display: block !important;
    }
  </style>
</head>

<body>

  <div class="container text-center">
    <!-- Mode Toggle -->
    <div class="mode-toggle" onclick="toggleMode()" title="Ganti Mode">
      <i id="mode-icon" class="fas fa-moon"></i>
    </div>

    <!-- Logo -->
    <div class="brand-logo">
      <img src="{{ asset('logo.png') }}" alt="Logo">
      <h1>{{ config('app.name', 'Laravel') }}</h1>
    </div>

    <!-- Login Button -->
    <a href="/" class="btn btn-login w-100 py-2 mb-4">
      <i class="fas fa-sign-in-alt me-1"></i> Login Admin
    </a>

    <!-- Attendance Info -->
    <div id="attendance-box" class="attendance-box">
      <h2 id="santri-name"><i class="fas fa-user"></i> Menunggu data...</h2>
      <p id="prayer-name"><i class="fas fa-mosque"></i> ---</p>
      <p id="status"><i class="fas fa-clock"></i> ---</p>
      <p id="time"><i class="fas fa-calendar-alt"></i> ---</p>
    </div>

    <!-- Loading Spinner -->
    <div id="loading" class="loading-spinner">
      <div class="spinner-border spinner-border-sm" role="status">
        <span class="visually-hidden">Loading...</span>
      </div>
    </div>
  </div>

  <script>
    let timeout;

    function fetchLatestAttendance() {
      document.getElementById('loading').classList.add('show');

      fetch('/api/attendance/latest')
        .then(response => response.json())
        .then(data => {
          if (data.santri) {
            document.getElementById('santri-name').innerHTML = `<i class="fas fa-user"></i> ${data.santri}`;
            document.getElementById('prayer-name').innerHTML = `<i class="fas fa-mosque"></i> Sholat: ${data.prayer}`;
            document.getElementById('status').innerHTML = `<i class="fas fa-clock"></i> Status: ${data.status}`;
            document.getElementById('time').innerHTML = `<i class="fas fa-calendar-alt"></i> Waktu: ${data.time}`;
            resetTimeout();
          }
        })
        .catch(error => console.error("Gagal mengambil data:", error))
        .finally(() => {
          document.getElementById('loading').classList.remove('show');
        });
    }

    function resetTimeout() {
      clearTimeout(timeout);
      timeout = setTimeout(resetDisplay, 5000);
    }

    function resetDisplay() {
      document.getElementById('santri-name').innerHTML = `<i class="fas fa-user"></i> Menunggu data...`;
      document.getElementById('prayer-name').innerHTML = `<i class="fas fa-mosque"></i> ---`;
      document.getElementById('status').innerHTML = `<i class="fas fa-clock"></i> ---`;
      document.getElementById('time').innerHTML = `<i class="fas fa-calendar-alt"></i> ---`;
    }

    setInterval(fetchLatestAttendance, 3000);

    // Mode toggle
    function toggleMode() {
      const body = document.body;
      const icon = document.getElementById("mode-icon");

      body.classList.toggle("light-mode");

      if (body.classList.contains("light-mode")) {
        icon.classList.replace("fa-moon", "fa-sun");
      } else {
        icon.classList.replace("fa-sun", "fa-moon");
      }
    }
  </script>

</body>
</html>
